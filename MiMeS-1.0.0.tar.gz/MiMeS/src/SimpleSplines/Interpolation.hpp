#ifndef Interpolation_head
#define Interpolation_head

#include"Interpolation_base.hpp"
#include"LinearSpline.hpp"
#include"CubicSpline.hpp"



#endif