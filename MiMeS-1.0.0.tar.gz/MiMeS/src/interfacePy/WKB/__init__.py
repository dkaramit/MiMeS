from .WKB import relic, getPoints

